-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: enjoytrip
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board`
--

DROP TABLE IF EXISTS `board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board` (
  `boardId` int NOT NULL AUTO_INCREMENT,
  `boardTitle` varchar(100) NOT NULL,
  `boardContent` text NOT NULL,
  `boardRegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `boardLike` int DEFAULT '0',
  `boardReadCount` int DEFAULT '0',
  `userId` int DEFAULT NULL,
  `boardClsf` char(3) DEFAULT '002',
  PRIMARY KEY (`boardId`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board`
--

LOCK TABLES `board` WRITE;
/*!40000 ALTER TABLE `board` DISABLE KEYS */;
INSERT INTO `board` VALUES (1,'kdh1 test1','<p>contenttest</p>','2023-11-23 08:49:03',0,1,2,'002'),(2,'kdh1 test1 ','content ','2023-11-23 08:52:53',0,1,2,'002'),(3,'kdh1 test2 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(4,'kdh1 test3 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(5,'kdh1 test4 ','content ','2023-11-23 08:52:53',0,1,2,'002'),(6,'kdh1 test5 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(7,'kdh1 test6 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(8,'kdh1 test7 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(9,'kdh1 test8 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(10,'kdh1 test9 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(11,'kdh1 test10 ','content ','2023-11-23 08:52:53',0,0,2,'002'),(12,'wjw1 test1 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(13,'wjw1 test2 ','content ','2023-11-23 08:53:57',0,1,3,'002'),(14,'wjw1 test3 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(15,'wjw1 test4 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(16,'wjw1 test5 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(17,'wjw1 test6 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(18,'wjw1 test7 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(19,'wjw1 test8 ','content ','2023-11-23 08:53:57',0,0,3,'002'),(20,'wjw1 test9 ','content ','2023-11-23 08:53:57',0,1,3,'002'),(21,'wjw1 test10 ','content ','2023-11-23 08:53:57',0,1,3,'002'),(22,'공지합니다','<p>껄껄</p>','2023-11-24 00:18:13',0,2,1,'001');
/*!40000 ALTER TABLE `board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-24 11:55:49
